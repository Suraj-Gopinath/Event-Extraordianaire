function validate(){
    var firstname=document.getElementById("firstname").value;
    var password=document.getElementById("password").value;
    var phone=document.getElementById("phone").value;
    var email=document.getElementById("email").value;
    if(firstname.length&&password.length&&phone.length&&email.length!=0)
    {
        alert("SIGN SUCCESSFUL!");
    }
        
    else if(firstname.length||phone.length||email.length==0||password.length<8)
    {
        alert("PLEASE ENTER THE REQUIRED DETAILS");
    }

}
