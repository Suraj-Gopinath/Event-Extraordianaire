function validate(){
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    var newpassword=document.getElementById("newpassword").value;
    
     if(password.length<8)
    {
        alert("PLEASE SET A PASSWORD WITH 8 OR MORE CHARACTERS");
        return false;  
    }
     if(username.length<1)
    {
        alert("PLEASE ENTER YOUR USERNAME");
        return false;  
    }
    else if(password==newpassword)
    {
        alert("PASSWORD CHANGED SUCCESSFULLY!");
        return false;
    }
    else{
        alert("PASSWORD AND RESET PASSWORD DON'T MATCH");
    }

}


